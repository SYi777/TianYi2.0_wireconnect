"""Logging utilities for the xROCS robot system.

This package provides logging functionality and configuration for the xROCS system,
including customizable log levels, formatters, handlers, and internationalization.
"""

# Locale files for xROCS i18n

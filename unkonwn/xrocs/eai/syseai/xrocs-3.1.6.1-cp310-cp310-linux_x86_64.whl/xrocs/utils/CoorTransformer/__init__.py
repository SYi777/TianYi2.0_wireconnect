"""Coordinate transformation utilities for xROCS robot system.

This package provides tools for transforming coordinates between different reference frames
in the robot system, such as robot base, camera, and end-effector frames.
"""

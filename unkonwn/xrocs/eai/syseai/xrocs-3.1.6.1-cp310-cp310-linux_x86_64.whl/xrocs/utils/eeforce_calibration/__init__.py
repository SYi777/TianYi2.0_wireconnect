"""Module for the xROCS framework."""

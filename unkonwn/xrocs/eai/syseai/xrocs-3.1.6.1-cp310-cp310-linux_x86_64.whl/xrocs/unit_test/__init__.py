"""Unit test for the xROCS framework."""

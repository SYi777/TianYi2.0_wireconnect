"""xROCS test scripts."""

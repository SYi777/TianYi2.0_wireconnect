"""Data collection package for xROCS.

This package contains tools and utilities for collecting and managing various types of data
used in robotic applications within the xROCS framework.
"""

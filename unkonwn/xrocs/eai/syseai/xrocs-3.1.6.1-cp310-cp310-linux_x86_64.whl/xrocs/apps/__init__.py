"""Applications package for xROCS.

This package contains various standalone applications and utilities built using the xROCS framework.
"""

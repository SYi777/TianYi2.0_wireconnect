"""Status checking package for xROCS.

This package provides utilities for checking the status and health of various
robotic components and systems within the xROCS framework.
"""

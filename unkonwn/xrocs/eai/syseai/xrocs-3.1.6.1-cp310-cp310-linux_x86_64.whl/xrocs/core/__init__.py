"""Core package for xROCS system containing main application components and functionality."""

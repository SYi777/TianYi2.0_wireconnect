"""Package for communication components and functionality in the xROCS system."""

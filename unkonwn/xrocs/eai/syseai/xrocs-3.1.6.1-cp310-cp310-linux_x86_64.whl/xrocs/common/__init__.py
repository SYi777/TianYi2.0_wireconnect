"""Common modules and utilities for the xROCS framework.

This package contains common data types, interfaces, and utilities
that are shared across different components of the xROCS framework.
"""

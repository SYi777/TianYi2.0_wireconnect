"""Common data types package for the xROCS framework.

This package contains fundamental data structures and types used throughout
the xROCS framework, including coordinate systems, rotations, poses, joints data,
bounding boxes, and base data classes.
"""

from xrocs.common.data_type.base_data import BaseArray, BaseData
from xrocs.common.data_type.bbox_data import Bbox2D, Bbox3D
from xrocs.common.data_type.coordinate_data import Coordinate, CoordinateArray
from xrocs.common.data_type.joints_data import Joints, JointsArray
from xrocs.common.data_type.pose_data import Pose, PoseArray
from xrocs.common.data_type.rotation_data import Rotation

__all__ = [
    "BaseArray",
    "BaseData",
    "Bbox2D",
    "Bbox3D",
    "Coordinate",
    "CoordinateArray",
    "Joints",
    "JointsArray",
    "Pose",
    "PoseArray",
    "Rotation",
]

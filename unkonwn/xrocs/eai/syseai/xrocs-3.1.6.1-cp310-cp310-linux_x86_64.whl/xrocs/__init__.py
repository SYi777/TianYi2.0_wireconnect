"""xROCS for robotics."""

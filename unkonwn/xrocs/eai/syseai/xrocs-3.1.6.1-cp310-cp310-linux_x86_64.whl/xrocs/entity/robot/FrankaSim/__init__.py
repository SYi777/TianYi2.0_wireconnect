"""FrankaSim robot simulation package for xROCS framework.

This package contains implementations for simulated Franka robot operations.
"""

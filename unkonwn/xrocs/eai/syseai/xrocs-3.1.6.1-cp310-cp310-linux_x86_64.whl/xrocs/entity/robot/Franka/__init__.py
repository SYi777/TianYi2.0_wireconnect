"""Franka control interface implementation."""

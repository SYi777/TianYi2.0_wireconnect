"""TienKung 3.0 robot module package for xROCS platform.

Changelog:
    - 2026-03-19 (Chris Ren): Initialize TienKung 3.0 robot module.
"""

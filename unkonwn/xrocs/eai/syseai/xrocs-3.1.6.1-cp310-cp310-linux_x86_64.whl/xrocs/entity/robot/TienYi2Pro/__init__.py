"""TienYi2 Pro robot module package for xROCS platform.

Changelog:
    - 2026-05-26 (Chris Ren): Initialize TienYi2 Pro robot module.
"""

"""TienKung Dex robot module package for xROCS platform.

Changelog:
    - 2025-11-05 (Chris Ren): Initialize TienKung Dex robot module.
"""

"""TienKung 3.0 robot controller module package for xROCS platform.

Changelog:
    - 2026-03-26 (Chris Ren): Initialize TienKung 3.0 robot controller module.
"""

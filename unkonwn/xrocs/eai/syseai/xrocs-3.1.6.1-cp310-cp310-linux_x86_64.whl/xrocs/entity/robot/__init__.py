"""Robot module package for xROCS platform.

This package contains various robot drivers and implementations for different robot types.
"""

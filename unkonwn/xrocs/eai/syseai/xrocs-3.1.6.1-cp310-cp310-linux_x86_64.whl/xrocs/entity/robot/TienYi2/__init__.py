"""TienYi2 robot module package for xROCS platform.

Changelog:
    - 2025-09-10 (Chris Ren): Initialize TienYi2 robot module.
"""

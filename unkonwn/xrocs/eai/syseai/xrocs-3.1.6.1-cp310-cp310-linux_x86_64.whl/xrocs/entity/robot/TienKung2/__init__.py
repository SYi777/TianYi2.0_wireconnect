"""TienKung2 robot module package for xROCS platform.

Changelog:
    - 2025-09-09 (Chris Ren): Initialize TienKung2 robot module.
"""

"""TienYi 2.0 Pro robot controller module package for xROCS platform.

This package adapts the TienKung 3.0 controller stack (base / mixin / per-group controllers) to the
TienYi 2.0 Pro hardware composition purely via inheritance.

Changelog:
    - 2026-05-26 (Chris Ren): Initialize TienYi 2.0 Pro robot controller module.
"""

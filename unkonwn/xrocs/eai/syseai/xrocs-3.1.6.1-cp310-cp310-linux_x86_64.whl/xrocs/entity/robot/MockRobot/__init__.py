"""MockRobot package for simulating robot behaviors without actual hardware."""

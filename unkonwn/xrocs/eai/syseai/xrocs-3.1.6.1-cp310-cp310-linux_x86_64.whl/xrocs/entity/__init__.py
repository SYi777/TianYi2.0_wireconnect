"""Entity package for the xROCS framework.

This package contains various entity implementations including robots, cameras, hands, etc.
"""

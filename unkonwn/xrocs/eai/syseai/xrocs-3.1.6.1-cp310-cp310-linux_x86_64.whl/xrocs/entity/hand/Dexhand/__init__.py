"""Dexhand package provides functionality for interfacing with and controlling Dexhand robotic hands.

This package contains classes and utilities for managing joint configurations, motions, and commands
for the Dexhand robotic hand system.
"""

"""Package for simulating Robotiq grippers on Franka robot arms."""

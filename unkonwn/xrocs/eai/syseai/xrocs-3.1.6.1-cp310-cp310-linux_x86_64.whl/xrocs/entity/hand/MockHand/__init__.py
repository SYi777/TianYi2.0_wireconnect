"""Package for mock hand implementation for testing and simulation purposes."""

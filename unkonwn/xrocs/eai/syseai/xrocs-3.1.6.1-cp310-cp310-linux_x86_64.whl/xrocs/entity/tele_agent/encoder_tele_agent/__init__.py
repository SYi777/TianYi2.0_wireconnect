"""Encoder tele-agent package for the xROCS framework.

This package contains various encoder tele-agent implementations.
"""

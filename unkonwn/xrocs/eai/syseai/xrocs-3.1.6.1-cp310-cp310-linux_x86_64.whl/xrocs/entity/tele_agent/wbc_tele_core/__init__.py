"""Whole body control tele-agent package for the xROCS framework.

This package contains the whole body control tele-agent implementations based on the xTele.
"""

"""Tele-agent package for the xROCS framework.

This package contains various tele-agent implementations.
"""

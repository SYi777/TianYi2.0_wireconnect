"""Robot package for Agilex robot arm drivers.

This package provides the implementation of the AgilexRobot class for
controlling Agilex robot arms through ROS interfaces.
"""

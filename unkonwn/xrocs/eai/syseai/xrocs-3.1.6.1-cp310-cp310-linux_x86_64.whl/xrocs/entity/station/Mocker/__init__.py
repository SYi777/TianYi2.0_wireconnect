"""Mock station package for simulating robot environments.

This package provides a mock implementation of a robot station that can be used
for testing and development without requiring real robot hardware.
"""

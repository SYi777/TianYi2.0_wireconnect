"""TienKung 3.0 robot station module package for xROCS platform.

Changelog:
    - 2026-04-02 (Chris Ren): Initialize TienKung 3.0 robot station module.
"""

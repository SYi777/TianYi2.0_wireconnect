"""ArxBot Robot package for robot arm control and manipulation.

This package provides robot arm driver implementations for the ArxBot platform,
including joint control, cartesian pose management, and motion capabilities.
"""

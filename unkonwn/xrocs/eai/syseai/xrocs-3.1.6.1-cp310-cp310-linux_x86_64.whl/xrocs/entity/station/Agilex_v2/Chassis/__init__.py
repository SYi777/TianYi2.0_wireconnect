"""Chassis package for the Agilex v2 robot platform.

This package provides chassis controller implementations for monitoring
and controlling the movement of the Agilex robot.
"""

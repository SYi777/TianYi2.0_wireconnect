"""UR robot station module package for xROCS platform.

Changelog:
    - 2025-12-15 (Chris Ren): Initialize UR robot station module.
"""

"""Camera package for the Agilex v2 robot platform.

This package provides camera driver implementations for accessing and processing
the RGB and depth camera streams from the Agilex robot.
"""

"""ArxBot Camera package for handling camera functionality in the ArxBot system.

This package provides camera driver implementations specific to the ArxBot platform,
including image acquisition and processing capabilities.
"""

"""TienYi2 robot station module package for xROCS platform.

Changelog:
    - 2025-09-15 (Chris Ren): Initialize TienYi2 robot station module.
"""

"""Camera package for Agilex station camera interfaces.

This package provides modules for accessing and controlling cameras
in the Agilex robotic station.
"""

"""Agilex_v1 package for controlling Agilex robot arms and cameras.

This package provides modules for interacting with Agilex robot arms and cameras
through the xROCS framework.
"""

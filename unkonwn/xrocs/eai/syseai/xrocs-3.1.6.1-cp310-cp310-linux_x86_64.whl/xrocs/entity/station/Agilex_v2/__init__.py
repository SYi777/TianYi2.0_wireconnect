"""Agilex v2 robot platform package.

This package contains modules for interfacing with the Agilex v2 robot platform,
including camera, chassis, robot arm, and teleoperator implementations.
"""

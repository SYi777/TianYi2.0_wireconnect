"""Robot package for the Agilex v2 robot platform.

This package provides robot arm driver implementations for controlling
and monitoring the robot arms on the Agilex robot.
"""

"""TienKung2 robot station module package for xROCS platform.

Changelog:
    - 2025-09-12 (Chris Ren): Initialize TienKung2 robot station module.
"""

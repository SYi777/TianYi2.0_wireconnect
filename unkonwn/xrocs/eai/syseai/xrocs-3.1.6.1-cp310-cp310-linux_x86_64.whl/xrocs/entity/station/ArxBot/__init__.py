"""Arxbot station module."""

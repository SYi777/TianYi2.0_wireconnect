"""ArxBot Teleoperator package for handling remote control of the robot.

This package provides teleoperation implementations for the ArxBot platform,
enabling remote control of robot arms, gripper, and other components.
"""

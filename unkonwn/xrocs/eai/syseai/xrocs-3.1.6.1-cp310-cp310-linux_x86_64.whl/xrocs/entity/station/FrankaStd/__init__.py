"""Package containing Franka standard station implementation for physical robot control."""

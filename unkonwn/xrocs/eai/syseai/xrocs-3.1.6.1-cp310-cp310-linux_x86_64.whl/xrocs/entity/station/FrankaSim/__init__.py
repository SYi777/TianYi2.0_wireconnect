"""Package containing Franka simulation station implementation for robot control."""

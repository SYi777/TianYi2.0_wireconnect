"""ArxBot Chassis package for controlling and monitoring the mobile base.

This package provides chassis driver implementations for the ArxBot platform,
including position control and state monitoring capabilities.
"""

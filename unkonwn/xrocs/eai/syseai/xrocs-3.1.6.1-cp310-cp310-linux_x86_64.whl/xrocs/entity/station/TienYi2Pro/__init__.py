"""TienYi 2.0 Pro robot station module package for xROCS platform.

Changelog:
    - 2026-05-26 (Chris Ren): Initialize TienYi 2.0 Pro robot station module.
"""

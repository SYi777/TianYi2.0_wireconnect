"""TienKung camera implementations."""

"""Camera package for the xROCS framework.

This package contains various camera implementations and drivers.
"""

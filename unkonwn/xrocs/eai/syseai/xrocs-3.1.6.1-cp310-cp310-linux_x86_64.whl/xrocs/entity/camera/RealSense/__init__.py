"""Camera package for the xROCS framework."""

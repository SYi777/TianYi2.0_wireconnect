"""Orbbec camera implementations."""

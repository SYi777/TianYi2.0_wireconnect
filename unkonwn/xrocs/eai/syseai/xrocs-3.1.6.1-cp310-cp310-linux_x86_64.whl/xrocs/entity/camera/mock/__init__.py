"""Mock camera implementations for testing."""

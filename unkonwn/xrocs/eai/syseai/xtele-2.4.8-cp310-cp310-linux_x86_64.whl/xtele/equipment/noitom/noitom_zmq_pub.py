#!/usr/bin/env python3
"""Publish Noitom retargeting results over ZeroMQ.

This module mirrors the publisher/subscriber shape used by ``xtele.core.manus_pub``:
``NoitomPublisher`` owns the hardware/runtime resources, streams in a background
thread, and ``NoitomSubscriber`` is a small debug client.
"""

from __future__ import annotations

import argparse
import importlib
import json
import sys
import threading
import time
from pathlib import Path
from typing import Optional

import zmq


PUB_HOST = "0.0.0.0"
PUB_PORT = 7013
UDP_PORT = 7012
PUB_FREQ = 1000.0
PRINT_RATE = 5.0
WAIT_LOG_INTERVAL = 2.0
NO_DATA_TIMEOUT = 1.0
DEFAULT_CONFIG_NAME = "tiangong2_4dof"


def get_runtime_root() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys._MEIPASS) / "retargeting_runtime"
    return Path(__file__).resolve().parent / "retargeting_runtime"


RUNTIME_ROOT = get_runtime_root()
sys.path.append(str(RUNTIME_ROOT / "3rdparty" / "MocapApi"))
sys.path.append(str(RUNTIME_ROOT / "3rdparty" / "robot-retargeting"))

mocap_api = importlib.import_module("mocap_api")
robot_retargeting = importlib.import_module("robot_retargeting")

MCPApplication = mocap_api.MCPApplication
MCPAvatar = mocap_api.MCPAvatar
MCPEventType = mocap_api.MCPEventType
MCPSettings = mocap_api.MCPSettings

MAX_CHILDREN_BONES = robot_retargeting.MAX_CHILDREN_BONES
MocapBone = robot_retargeting.MocapBone
RetargetingCreateHandle = robot_retargeting.RetargetingCreateHandle
RetargetingDestroyHandle = robot_retargeting.RetargetingDestroyHandle
RetargetingGetAvatarState = robot_retargeting.RetargetingGetAvatarState
RetargetingMocapData = robot_retargeting.RetargetingMocapData


def create_mocap_bones(avatar):
    """Convert one mocap avatar frame to the retargeting library input."""
    mocap_bones = []
    for joint in avatar.get_joints():
        bone = MocapBone()
        bone.name = joint.get_name()
        if hasattr(joint, "get_tag"):
            bone.tag = joint.get_tag()
        bone.local_position = joint.get_local_position()
        bone.local_rotation = joint.get_local_rotation()

        children = joint.get_children()
        bone.set_children_count(min(len(children), MAX_CHILDREN_BONES))
        for index, child in enumerate(children[:MAX_CHILDREN_BONES]):
            bone.set_child_name(index, child.get_name())

        mocap_bones.append(bone)
    return mocap_bones


def resolve_config_file(config_name: str, config_root: str | Path) -> Path:
    config_root_path = Path(config_root)
    if not config_root_path.is_absolute():
        config_root_path = (RUNTIME_ROOT / config_root_path).resolve()

    config_file = config_root_path / config_name / f"{config_name}.conf"
    if not config_file.exists():
        raise FileNotFoundError(f"Config file not found: {config_file}")
    return config_file


def build_retargeting_payload(result, avatar_state):
    joint_names = result.joint_names
    positions = result.positions
    joint_count = min(len(joint_names), len(positions))

    payload = {
        "timestamp": int(time.time() * 1000), # ms
        "device_type": "noitom_cloth",
        "status": "data",
        "data": {
            "retargeting_timestamp": result.timestamp,
            "root_position": result.root_position,
            "root_rotation": result.root_rotation,
            "root_velocity": result.root_velocity,
            "root_angular_velocity": result.root_angular_velocity,
            "joint_count": result.joint_count,
            "joints": {
                joint_names[index]: positions[index] for index in range(joint_count)
            },
            "avatar_bone_count": (
                len(avatar_state.bone_names) if avatar_state is not None else 0
            ),
        },
    }
    return payload


def publish_retargeting_payload(pub_socket, payload, print_message=False):
    message = json.dumps(payload, ensure_ascii=False)
    pub_socket.send_string(message)
    if print_message:
        print(message)


def run(args):
    config_file = resolve_config_file(args.config_name, args.config_root)
    print(f"Config file: {config_file}")
    print(f"Listening for BVH mocap data on UDP port {args.udp_port}")

    app = MCPApplication()
    settings = MCPSettings()
    settings.set_udp(args.udp_port)
    settings.set_bvh_rotation(args.bvh_rotation)
    app.set_settings(settings)

    retargeting_handle = None
    zmq_context = None
    pub_socket = None
    last_print_time = 0.0
    last_receive_time = 0.0
    last_wait_log_time = 0.0

    try:
        app.open()
        retargeting_handle = RetargetingCreateHandle(str(config_file))
        zmq_context = zmq.Context()
        pub_socket = zmq_context.socket(zmq.PUB)
        pub_socket.bind(args.pub_endpoint)
        print("Mocap and retargeting initialized. Press Ctrl+C to stop.")
        print(f"Publishing retargeting JSON with ZeroMQ PUB on {args.pub_endpoint}")

        while True:
            now = time.perf_counter()
            events = app.poll_next_event()

            if not events and now - last_wait_log_time > args.wait_log_interval:
                print("Waiting for AvatarUpdated mocap data...")
                last_wait_log_time = now

            for event in events:
                if event.event_type != MCPEventType.AvatarUpdated:
                    continue

                avatar = MCPAvatar(event.event_data.avatar_handle)
                mocap_bones = create_mocap_bones(avatar)
                success, result = RetargetingMocapData(
                    retargeting_handle,
                    mocap_bones,
                )
                last_receive_time = now

                if not success:
                    print("Retargeting failed for current mocap frame.")
                    continue

                avatar_success, avatar_state = RetargetingGetAvatarState(
                    retargeting_handle
                )
                if not avatar_success:
                    avatar_state = None

                payload = build_retargeting_payload(
                    result,
                    avatar_state,
                )
                should_print = now - last_print_time >= 1.0 / args.print_rate
                publish_retargeting_payload(
                    pub_socket,
                    payload,
                    should_print,
                )
                if should_print:
                    last_print_time = now

            if last_receive_time and now - last_receive_time > NO_DATA_TIMEOUT:
                print(f"No mocap data received for {NO_DATA_TIMEOUT:.1f}s")
                last_receive_time = 0.0

            time.sleep(args.poll_interval)
    finally:
        if pub_socket is not None:
            pub_socket.close(linger=0)
        if zmq_context is not None:
            zmq_context.term()
        if retargeting_handle is not None:
            RetargetingDestroyHandle(retargeting_handle)
        app.close()
        print("Stopped.")


class NoitomPublisher:
    """Publisher wrapper used by ``xtele --zmqpub noitom``."""

    def __init__(
        self,
        config_name: str = DEFAULT_CONFIG_NAME,
        config_root: str = "config",
        udp_port: int = UDP_PORT,
        bvh_rotation: int = 0,
        pub_endpoint: str = f"tcp://*:{PUB_PORT}",
        print_rate: float = PRINT_RATE,
        poll_interval: float = 0.001,
        wait_log_interval: float = WAIT_LOG_INTERVAL,
        config_path: str | None = None,
    ):
        # config_path is accepted for consistency with other ZMQ publishers.
        self.config_path = config_path
        self.args = argparse.Namespace(
            config_name=config_name,
            config_root=config_root,
            udp_port=udp_port,
            bvh_rotation=bvh_rotation,
            pub_endpoint=pub_endpoint,
            print_rate=print_rate,
            poll_interval=poll_interval,
            wait_log_interval=wait_log_interval,
        )

    def serve(self):
        try:
            run(self.args)
        except KeyboardInterrupt:
            print("\n[NoitomPublisher] received Ctrl+C, stopping...")


def main():
    parser = argparse.ArgumentParser(
        description="Noitom mocap retargeting publisher without ROS."
    )
    parser.add_argument(
        "config_name",
        nargs="?",
        type=str,
        default=DEFAULT_CONFIG_NAME,
        help="Config name under retargeting_runtime/config/. Defaults to tiangong2_4dof.",
    )
    parser.add_argument(
        "--config-root",
        type=str,
        default="config",
        help="Config root directory. Relative paths are resolved from retargeting_runtime.",
    )
    parser.add_argument("--udp-port", type=int, default=7012)
    parser.add_argument("--bvh-rotation", type=int, default=0)
    parser.add_argument(
        "--print-rate",
        type=float,
        default=5.0,
        help="Console JSON print rate. ZeroMQ publishes every retargeted mocap frame.",
    )
    parser.add_argument("--pub-endpoint", type=str, default="tcp://*:7013")
    parser.add_argument("--poll-interval", type=float, default=0.001)
    parser.add_argument("--wait-log-interval", type=float, default=2.0)
    args = parser.parse_args()

    if args.print_rate <= 0:
        parser.error("--print-rate must be greater than 0")
    if args.poll_interval <= 0:
        parser.error("--poll-interval must be greater than 0")

    try:
        run(args)
    except KeyboardInterrupt:
        print("\nInterrupted by user.")


if __name__ == "__main__":
    main()

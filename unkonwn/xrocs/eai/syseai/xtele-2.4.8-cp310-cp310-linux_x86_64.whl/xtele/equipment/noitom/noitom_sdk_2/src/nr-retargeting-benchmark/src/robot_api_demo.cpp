#include <MocapApi/MocapApi.h>

#include <iostream>
#include <memory>
#include <thread>

#include "mocap_utils.h"

#if defined(ROS1)
#include <ros/package.h>
#include <ros/ros.h>
#elif defined(ROS2)
#include <ament_index_cpp/get_package_share_directory.hpp>
#include <rclcpp/rclcpp.hpp>
#endif

int main(int argc, char** argv) {
#if defined(ROS1)
    ros::init(argc, argv, "benchmark");
    std::string package_path = ros::package::getPath("nr-retargeting-benchmark-cpp");
#elif defined(ROS2)
    rclcpp::init(argc, argv);
    std::string package_path = ament_index_cpp::get_package_share_directory("nr-retargeting-benchmark-cpp");
#endif
    std::cout << "Config Path: " << package_path << std::endl;

    std::string robot_name = argv[1];
    std::string config_file = package_path + "/config/" + robot_name + "/" + robot_name + ".conf";

    MocapUtils mocapHandler(config_file);

#if defined(ROS1)
    ros::Timer timer = mocapHandler.nh.createTimer(ros::Duration(0.002), &MocapUtils::TimerDriveRobot, &mocapHandler);
    ros::MultiThreadedSpinner spinner(2);
    ros::spin();
#elif defined(ROS2)
    auto timer = mocapHandler.nh->create_wall_timer(std::chrono::milliseconds(2),
                                                    std::bind(&MocapUtils::TimerDriveRobot, &mocapHandler));
    rclcpp::spin(mocapHandler.nh);
    rclcpp::shutdown();
#endif

    return 0;
}

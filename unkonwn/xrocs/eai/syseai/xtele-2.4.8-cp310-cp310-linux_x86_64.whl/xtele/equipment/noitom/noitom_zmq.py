"""Noitom mocap retargeting subscriber over ZeroMQ.

Counterpart of the publisher in
``mocap_retargeting_no_ros.py``, which binds a ``zmq.PUB``
socket and broadcasts retargeting results as JSON.

Provides a drop-in replacement for ``noitom_ros2.Noitom`` so callers
relying on ``act_dict()`` keep working without changes.
"""

from __future__ import annotations

import json
import math
import time
from collections import deque
from threading import Event, Lock, Thread
from typing import Optional

import numpy as np
import zmq

from xtele.equipment.tele_base import TeleBase


_WBC_FIELDS = (
    "body_pos_w",       # (1, 24, 3)
    "body_quat_w",      # (1, 24, 4)
    "joint_pos",        # (1, 23)
    "joint_vel",        # (1, 23)
    "root_lin_vel_w",   # (1, 3)
    "root_ang_vel_w",   # (1, 3)
)


OUTPUT_JOINT_NAME = [
    # head (3)
    "head_pitch",
    "head_yaw",
    "head_roll",
    # left arm (7)
    "left_joint1",
    "left_joint2",
    "left_joint3",
    "left_joint4",
    "left_joint5",
    "left_joint6",
    "left_joint7",
    # right arm (7)
    "right_joint1",
    "right_joint2",
    "right_joint3",
    "right_joint4",
    "right_joint5",
    "right_joint6",
    "right_joint7",
    # waist / body (3)
    "waist_pitch",
    "waist_yaw",
    "waist_roll",
    # left leg (6)
    "left_hip_pitch",
    "left_hip_roll",
    "left_hip_yaw",
    "left_knee_pitch",
    "left_ankle_pitch",
    "left_ankle_roll",
    # right leg (6)
    "right_hip_pitch",
    "right_hip_roll",
    "right_hip_yaw",
    "right_knee_pitch",
    "right_ankle_pitch",
    "right_ankle_roll",
    # flanges (2)
    "left_flange",
    "right_flange",
    # left hand (12)
    "L_thumb_proximal_yaw_joint",
    "L_thumb_proximal_pitch_joint",
    "L_thumb_intermediate_joint",
    "L_thumb_distal_joint",
    "L_index_proximal_joint",
    "L_index_intermediate_joint",
    "L_middle_proximal_joint",
    "L_middle_intermediate_joint",
    "L_ring_proximal_joint",
    "L_ring_intermediate_joint",
    "L_pinky_proximal_joint",
    "L_pinky_intermediate_joint",
    # right hand (12)
    "R_thumb_proximal_yaw_joint",
    "R_thumb_proximal_pitch_joint",
    "R_thumb_intermediate_joint",
    "R_thumb_distal_joint",
    "R_index_proximal_joint",
    "R_index_intermediate_joint",
    "R_middle_proximal_joint",
    "R_middle_intermediate_joint",
    "R_ring_proximal_joint",
    "R_ring_intermediate_joint",
    "R_pinky_proximal_joint",
    "R_pinky_intermediate_joint",
]

_JOINT_NAME_MAP = {
    # head
    "head_pitch": "head_pitch_joint",
    "head_yaw": "head_yaw_joint",
    "head_roll": "head_roll_joint",
    # left arm
    "left_joint1": "shoulder_pitch_l_joint",
    "left_joint2": "shoulder_roll_l_joint",
    "left_joint3": "shoulder_yaw_l_joint",
    "left_joint4": "elbow_pitch_l_joint",
    "left_joint5": "elbow_yaw_l_joint",
    "left_joint6": "wrist_pitch_l_joint",
    "left_joint7": "wrist_roll_l_joint",
    # right arm
    "right_joint1": "shoulder_pitch_r_joint",
    "right_joint2": "shoulder_roll_r_joint",
    "right_joint3": "shoulder_yaw_r_joint",
    "right_joint4": "elbow_pitch_r_joint",
    "right_joint5": "elbow_yaw_r_joint",
    "right_joint6": "wrist_pitch_r_joint",
    "right_joint7": "wrist_roll_r_joint",
    # waist / body
    "waist_pitch": "body_pitch_joint",
    "waist_yaw": "body_yaw_joint",
    "waist_roll": "body_roll_joint",
    # left leg
    "left_hip_pitch": "hip_pitch_l_joint",
    "left_hip_roll": "hip_roll_l_joint",
    "left_hip_yaw": "hip_yaw_l_joint",
    "left_knee_pitch": "knee_pitch_l_joint",
    "left_ankle_pitch": "ankle_pitch_l_joint",
    "left_ankle_roll": "ankle_roll_l_joint",
    # right leg
    "right_hip_pitch": "hip_pitch_r_joint",
    "right_hip_roll": "hip_roll_r_joint",
    "right_hip_yaw": "hip_yaw_r_joint",
    "right_knee_pitch": "knee_pitch_r_joint",
    "right_ankle_pitch": "ankle_pitch_r_joint",
    "right_ankle_roll": "ankle_roll_r_joint",
}

_JOINT_LIMITS_DEG: dict = {
    # head
    "head_pitch":        (-50.0, 15.0),
    "head_yaw":          (-60.0, 60.0),
    # left arm
    "left_joint1":       (-163.0, 163.0),  # shoulder_pitch_l
    "left_joint2":       (-11.0, 191.0),   # shoulder_roll_l
    "left_joint3":       (-163.0, 163.0),  # shoulder_yaw_l
    "left_joint4":       (-146.0, 11.0),   # elbow_pitch_l
    "left_joint5":       (-163.0, 163.0),  # elbow_yaw_l
    "left_joint6":       (-76.0, 76.0),    # wrist_pitch_l
    "left_joint7":       (-76.0, 76.0),    # wrist_roll_l
    # right arm — only shoulder_roll is mirrored per URDF; others match left
    "right_joint1":      (-163.0, 163.0),  # shoulder_pitch_r
    "right_joint2":      (-191.0, 11.0),   # shoulder_roll_r (mirrored)
    "right_joint3":      (-163.0, 163.0),  # shoulder_yaw_r
    "right_joint4":      (-146.0, 11.0),   # elbow_pitch_r (same as left)
    "right_joint5":      (-163.0, 163.0),  # elbow_yaw_r
    "right_joint6":      (-76.0, 76.0),    # wrist_pitch_r
    "right_joint7":      (-76.0, 76.0),    # wrist_roll_r
    # waist
    "waist_pitch":       (-30.0, 50.0),
    "waist_roll":        (-25.0, 25.0),
    "waist_yaw":         (-150.0, 185.0),
    # left leg
    "left_hip_pitch":    (-175.0, 160.0),
    "left_hip_roll":     (-24.0, 150.0),
    "left_hip_yaw":      (-80.0, 255.0),
    "left_knee_pitch":   (-5.0, 145.0),
    "left_ankle_pitch":  (-68.0, 30.0),
    "left_ankle_roll":   (-30.0, 30.0),
    # right leg — hip_roll and hip_yaw mirrored per URDF; others match left
    "right_hip_pitch":   (-175.0, 160.0),
    "right_hip_roll":    (-150.0, 24.0),   # mirrored
    "right_hip_yaw":     (-255.0, 80.0),   # mirrored
    "right_knee_pitch":  (-5.0, 145.0),
    "right_ankle_pitch": (-68.0, 30.0),
    "right_ankle_roll":  (-30.0, 30.0),
}

_JOINT_LIMITS_RAD: dict = {
    name: (math.radians(lo), math.radians(hi))
    for name, (lo, hi) in _JOINT_LIMITS_DEG.items()
}


class Noitom(TeleBase):
    """Subscribe to the Noitom retargeting publisher over ZeroMQ."""

    def __init__(
        self,
        sub_endpoint: str = "tcp://10.11.83.97:7013",
        identifier: str = "noitom_zmq",
        freq: float = 100.0,
        is_mock: bool = False,
    ):
        """
        Args:
            sub_endpoint: ZMQ endpoint of the publisher (matches
                ``mocap_retargeting_no_ros.py --pub-endpoint``).
            identifier: Logical identifier for this teleop source.
            freq: Polling frequency (Hz) of the non-blocking recv worker.
                Combined with ``zmq.CONFLATE``, this caps the effective
                data-refresh rate; pick something >= publisher rate.
            is_mock: When ``True``, no ZMQ socket / reader thread is created
                and ``act_dict()`` returns an all-zero output for every joint
                in ``OUTPUT_JOINT_NAME``. Useful for offline testing.
        """
        super().__init__(identifier=identifier)

        self._sub_endpoint = sub_endpoint
        self._poll_freq = max(float(freq), 1.0)
        self._is_mock = bool(is_mock)

        self._joint_states: dict = {}
        self._wbc: dict = {}
        self._latest_payload: Optional[dict] = None
        self._last_recv_time: float = 0.0
        self._time_window: deque = deque(maxlen=100)

        self._context = None
        self._socket = None
        self._mutex = Lock()
        self._stop_thread_flag = Event()
        self._read_thread: Optional[Thread] = None

        if self._is_mock:
            print(f"[{self.identifier}] started in MOCK mode (all-zero output)")
            return

        self._context = zmq.Context.instance()
        self._socket = self._context.socket(zmq.SUB)
        self._socket.setsockopt(zmq.CONFLATE, 1)  # 只取最新的数据
        self._socket.setsockopt(zmq.LINGER, 0)
        self._socket.connect(sub_endpoint)
        self._socket.setsockopt(zmq.SUBSCRIBE, b"")

        self._read_thread = Thread(
            target=self._read_worker,
            name=f"{identifier}-reader",
            daemon=True,
        )
        self._read_thread.start()

        print(f"[{self.identifier}] started, subscribing to {sub_endpoint}")

    def _read_worker(self) -> None:
        period = 1.0 / self._poll_freq
        prev_recv_time: Optional[float] = None
        while not self._stop_thread_flag.is_set():
            loop_start = time.perf_counter()
            payload: Optional[dict] = None
            try:
                data = self._socket.recv(flags=zmq.NOBLOCK)
                payload = json.loads(data.decode("utf-8"))
            except zmq.Again:
                pass
            except zmq.ContextTerminated:
                break
            except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                print(f"[{self.identifier}] failed to decode payload: {exc}")
            except zmq.ZMQError as exc:
                if self._stop_thread_flag.is_set():
                    break
                print(f"[{self.identifier}] zmq recv error: {exc}")

            if payload is not None:
                inner = payload.get("data") or {}
                joints = inner.get("joints") or {}
                wbc_raw = inner.get("wbc") or {}
                wbc = {
                    key: np.asarray(wbc_raw[key], dtype=np.float32)
                    for key in _WBC_FIELDS
                    if key in wbc_raw
                }
                now = time.perf_counter()
                with self._mutex:
                    self._latest_payload = payload
                    self._joint_states = joints
                    self._wbc = wbc
                    self._last_recv_time = now
                if prev_recv_time is not None:
                    self._time_window.append(now - prev_recv_time)
                prev_recv_time = now

            elapsed = time.perf_counter() - loop_start
            if elapsed < period:
                time.sleep(period - elapsed)

    def act(self):
        return self.act_dict()

    def act_dict(self) -> dict:
        if self._is_mock:
            return {name: 0.0 for name in OUTPUT_JOINT_NAME}

        with self._mutex:
            if self._latest_payload is None:
                return {}
            joints = dict(self._joint_states)
            # wbc = dict(self._wbc)

        normal: dict = {}
        for name in OUTPUT_JOINT_NAME:
            mapped = _JOINT_NAME_MAP.get(name, name)
            if mapped not in joints:
                continue
            value = joints[mapped]
            limits = _JOINT_LIMITS_RAD.get(name)
            if limits is not None:
                lo, hi = limits
                if value < lo:
                    value = lo
                elif value > hi:
                    value = hi
            normal[name] = value

        return normal

    def is_alive(self, max_age_s: float = 1.0) -> bool:
        if self._is_mock:
            return True
        with self._mutex:
            last = self._last_recv_time
        return last > 0 and (time.perf_counter() - last) < max_age_s

    def close(self) -> None:
        self._stop_thread_flag.set()
        if self._read_thread is not None and self._read_thread.is_alive():
            self._read_thread.join(timeout=1.0)
        if self._socket is not None:
            try:
                self._socket.close(linger=0)
            except Exception:
                pass
        print(f"[{self.identifier}] closed.")


if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(
        description="Subscribe to noitom retargeting JSON over ZMQ."
    )
    parser.add_argument(
        "--sub-endpoint",
        type=str,
        default="tcp://10.11.83.97:7013",
        help="ZMQ PUB endpoint to connect to.",
    )
    parser.add_argument(
        "--print-rate",
        type=float,
        default=100.0,
        help="Console print rate in Hz.",
    )
    args = parser.parse_args()

    noitom = Noitom(sub_endpoint=args.sub_endpoint)
    period = 0.01
    try:
        while True:
            # print(noitom.act_dict())
            time.sleep(period)
    except KeyboardInterrupt:
        print("\nInterrupted by user.")
    finally:
        noitom.close()

#ifndef _MOCAP_UTILS_H_
#define _MOCAP_UTILS_H_

// ROS version detection
#if defined(ROS1)
#include <geometry_msgs/TransformStamped.h>
#include <nav_msgs/Odometry.h>
#include <ros/package.h>
#include <ros/ros.h>
#include <sensor_msgs/JointState.h>
#include <tf2_ros/transform_broadcaster.h>
#elif defined(ROS2)
#include <tf2_ros/transform_broadcaster.h>

#include <ament_index_cpp/get_package_share_directory.hpp>
#include <geometry_msgs/msg/transform_stamped.hpp>
#include <nav_msgs/msg/odometry.hpp>
#include <rclcpp/rclcpp.hpp>
#include <sensor_msgs/msg/joint_state.hpp>
#endif

#include <tf2/LinearMath/Quaternion.h>

#include <thread>

#include "MocapApi/MocapApi.h"
#include "robot-retargeting/robot_retargeting.h"

using namespace MocapApi;

class Retargeting;
typedef std::shared_ptr<Retargeting> RetargetingPtr;

class MocapUtils {
   public:
    MocapUtils(const std::string& config_json);
    ~MocapUtils();

    void MocapProcessLoop();

#if defined(ROS1)
    void TimerDriveRobot(const ros::TimerEvent&);
#elif defined(ROS2)
    void TimerDriveRobot();
#endif

    uint32_t localPort = 7012;

    // global error
    EMCPError error = EMCPError::Error_None;
    // globalApp handle
    IMCPApplication* pGlobalApp = nullptr;
    MCPApplicationHandle_t globalAppHandle = 0;
    // globalSetting handle
    IMCPSettings* pGlobalSetting = nullptr;
    MCPSettingsHandle_t globalSettingHandle = 0;
    // #ifdef _SUPORT_ALICE_NEW_
    // Alice databus
    IMCPAliceHub* pAliceDataHub = nullptr;
    MCPAliceBusHandle_t aliceBusHandle = 0;
    // #endif
    // avatar handle
    IMCPAvatar* pAvatarInterface = nullptr;
    MCPAvatarHandle_t avatarHandle = 0;
    // Device handle
    IMCPTracker* pDeviceInterface = nullptr;
    MCPTrackerHandle_t deviceHandle = 0;
    // IMU
    IMCPSensorModule* pImuInterface = nullptr;
    MCPSensorModuleHandle_t imuHandle = 0;
    // #ifdef _SUPORT_ALICE_NEW_
    // Marker
    IMCPMarker* pMarkerInterface = nullptr;
    MCPMarkerHandle_t markerHandle = 0;
    // #endif
    // rigidbody
    IMCPRigidBody* pRigidbodyInterface = nullptr;
    MCPRigidBodyHandle_t rigidbodyHandle = 0;
    // #ifdef _SUPORT_ALICE_NEW_
    // Tracker/PWR
    IMCPPWR* pPWRInterface = nullptr;
    MCPPWRHandle_t pwrHandle = 0;
    // #endif
    // RenderSetting
    IMCPRenderSettings* pRenderSetting = nullptr;
    MCPRenderSettingsHandle_t renderSettingHandle = 0;

    // MaxEventCount
    static constexpr uint32_t nMaxEventCount = 16;
    // events
    MCPEvent_t pEvents[nMaxEventCount] = {};
    // EventCount
    uint32_t nEventCount = 0;
    // joint
    MCPJointHandle_t joint = 0;
    // all joint
    MCPJointHandle_t alljoint[59] = {};

    MocapApi::IMCPJoint* jointMgr = nullptr;

    //
    uint64_t mRobotRetargeting = 0;

    std::thread* mThread = nullptr;

#if defined(ROS1)
    ros::NodeHandle nh;
    ros::Publisher mPublisher;
    std::unique_ptr<tf2_ros::TransformBroadcaster> mTfBroadcaster;
#elif defined(ROS2)
    rclcpp::Node::SharedPtr nh;
    rclcpp::Publisher<sensor_msgs::msg::JointState>::SharedPtr mPublisher;
    std::unique_ptr<tf2_ros::TransformBroadcaster> mTfBroadcaster;
#endif

   private:
#if defined(ROS2)
    bool is_running() const {
        return rclcpp::ok();
    }
#else
    bool is_running() const {
        return ros::ok();
    }
#endif

    int setMCPSettings(IMCPSettings* setting, MCPSettingsHandle_t handle);

    void CreateMocapBones(MCPAvatarHandle_t mocapAvatarHandle, std::vector<MocapBone>& mocapBones);
};

#endif

#ifndef _ROBOT_RETARGETING_H_
#define _ROBOT_RETARGETING_H_

#include <string>
#include <vector>

struct MocapBone {
    std::string mName;
    int mTag;

    std::vector<std::string> msChildrenBoneName;

    float mLocalPosition[3];  // [x, y, z]
    float mLocalRotation[4];  // [w, x, y, z]
};

struct RetargetingResult {
    uint64_t mTimestamp;     // ms
    float mRootPosition[3];  // [x, y, z]
    float mRootRotation[4];  // [w, x, y, z]

    std::vector<std::string> mName;
    std::vector<double> mPosition;
    std::vector<double> mVelocity;
    std::vector<double> mEffort;
};

#ifdef __cplusplus
extern "C" {
#endif

uint64_t RetargetingCreateHandle(const char* config_file);

void RetargetingDestroyHandle(uint64_t);

void RetargetingUpdateMocapData(uint64_t, const std::vector<MocapBone>& mocapBones);

bool RetargetingGetResult(uint64_t, RetargetingResult& result);

#ifdef __cplusplus
}
#endif

#endif  // _ROBOT_RETARGETING_H_

import os
import rospy
from sensor_msgs.msg import JointState
from geometry_msgs.msg import PoseArray

from xtele.equipment.tele_base import TeleBase
import json
import pickle
from pathlib import Path
import datetime

OUTPUT_JOINT_NAME = [
    "head_pitch",
    "head_yaw",
    "head_roll",
    "left_joint1",
    "left_joint2",
    "left_joint3",
    "left_joint4",
    "left_joint5",
    "left_joint6",
    "left_joint7",
    "right_joint1",
    "right_joint2",
    "right_joint3",
    "right_joint4",
    "right_joint5",
    "right_joint6",
    "right_joint7",
    "waist_pitch",
    "waist_yaw",
    "waist_roll",
    "L_thumb_proximal_yaw_joint",
    "L_thumb_intermediate_joint",
    "L_index_intermediate_joint",
    "L_middle_intermediate_joint",
    "L_ring_intermediate_joint",
    "L_pinky_intermediate_joint",
    "R_thumb_proximal_yaw_joint",
    "R_thumb_intermediate_joint",
    "R_index_intermediate_joint",
    "R_middle_intermediate_joint",
    "R_ring_intermediate_joint",
    "R_pinky_intermediate_joint",
    "Height",
]

# BONES_NAME_PARENT: BONE: IT'S PARENT
BONES_NAME_PARENT = {
    "LeftHandPinky3": "LeftHandPinky2",
    "LeftHandPinky2": "LeftHandPinky1",
    "LeftHandRing1": "LeftInHandRing",
    "LeftHandMiddle2": "LeftHandMiddle1",
    "LeftInHandMiddle": "LeftHand",
    "LeftHandThumb3": "LeftHandThumb2",
    "LeftHandThumb1": "LeftHand",
    "LeftHand": "LeftForeArm",
    "LeftInHandPinky": "LeftHand",
    "LeftHandRing2": "LeftHandRing1",
    "LeftForeArm": "LeftArm",
    "LeftHandMiddle3": "LeftHandMiddle2",
    "LeftArm": "LeftShoulder",
    "LeftHandThumb2": "LeftHandThumb1",
    "LeftShoulder": "Spine2",
    "RightHandPinky3": "RightHandPinky2",
    "RightHandPinky2": "RightHandPinky1",
    "RightHandPinky1": "RightInHandPinky",
    "LeftInHandIndex": "LeftHand",
    "RightHandRing1": "RightInHandRing",
    "LeftHandPinky1": "LeftInHandPinky",
    "Neck": "Spine2",
    "RightForeArm": "RightArm",
    "LeftLeg": "LeftUpLeg",
    "RightInHandPinky": "RightHand",
    "Spine2": "Spine1",
    "RightFoot": "RightLeg",
    "RightHandRing2": "RightHandRing1",
    "RightUpLeg": "Hips",
    "Hips": "World",
    "RightHandIndex3": "RightHandIndex2",
    "RightHandMiddle2": "RightHandMiddle1",
    "Neck1": "Neck",
    "Spine": "Hips",
    "LeftFoot": "LeftLeg",
    "Head": "Neck1",
    "LeftUpLeg": "Hips",
    "LeftHandRing3": "LeftHandRing2",
    "LeftHandIndex1": "LeftInHandIndex",
    "Spine1": "Spine",
    "LeftInHandRing": "LeftHand",
    "LeftHandIndex2": "LeftHandIndex1",
    "RightHandThumb2": "RightHandThumb1",
    "RightLeg": "RightUpLeg",
    "RightHandThumb1": "RightHand",
    "RightArm": "RightShoulder",
    "RightHandMiddle1": "RightInHandMiddle",
    "RightInHandMiddle": "RightHand",
    "RightHandRing3": "RightHandRing2",
    "RightHand": "RightForeArm",
    "LeftHandIndex3": "LeftHandIndex2",
    "RightShoulder": "Spine2",
    "RightHandThumb3": "RightHandThumb2",
    "LeftHandMiddle1": "LeftInHandMiddle",
    "RightInHandIndex": "RightHand",
    "RightHandIndex1": "RightInHandIndex",
    "RightHandIndex2": "RightHandIndex1",
    "RightHandMiddle3": "RightHandMiddle2",
    "RightInHandRing": "RightHand",
}

class Noitom(TeleBase):
    def __init__(self):
        super().__init__()
        self._joint_states = None

        try:
            rospy.init_node("tele_station_node", anonymous=True)
        except rospy.exceptions.ROSException:
            pass
        self._joint_states_sub = rospy.Subscriber(
            "/joint_states", JointState, self._joint_states_callback
        )
        self.dt = datetime.datetime.now()
        rospy.Subscriber("/avatar_bone_poses", PoseArray, self._bones_call_back)

        rospy.sleep(3)

    def _shutdown_hook(self):
        self._joint_states_sub.unregister()
        self._joint_states_sub = None

    def _joint_states_callback(self, msg):
        self._joint_states = msg

    def save_frame(self, 
        folder: Path,
        timestamp: datetime.datetime,
        obs: dict,
        # action: dict,
    ) -> None:
        """Save a frame of data to a file.

        Args:
            folder (Path): The directory where the data will be saved.
            timestamp (datetime.datetime): The timestamp of the data.
            obs (dict):_bones_call_back The observation data.
            action (dict): The action data.
        """
        # obs = obs.copy()
        # obs["control"] = action  # add action to obs

        # make folder if it doesn't exist
        folder.mkdir(exist_ok=True, parents=True)
        recorded_file = folder / (timestamp.isoformat() + ".pkl")

        with open(recorded_file, "wb") as f:
            pickle.dump(obs, f)

    def _bones_call_back(self, msg):
        bones_dict = {}
        for idx, name in enumerate(BONES_NAME_PARENT.keys()):
            bones_dict[name] = {
                "parent": BONES_NAME_PARENT[name],
                "child": [
                    key for key, value in BONES_NAME_PARENT.items() if value == name
                ],
                "position_xyz": [
                    msg.poses[idx].position.x,
                    msg.poses[idx].position.y,
                    msg.poses[idx].position.z,
                ],
                "orientation_xyzw": [
                    msg.poses[idx].orientation.x,
                    msg.poses[idx].orientation.y,
                    msg.poses[idx].orientation.z,
                    msg.poses[idx].orientation.w,
                ],
            }

        self.bones_state_dict = bones_dict

        bones_dict["timestamp"] = rospy.Time.now().to_sec()
        bones_dict["name"] = "noitom_bones_state"
        with open("noitom_data.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps(bones_dict, ensure_ascii=False) + "\n")

    def get_bones_state(self):
        return self.bones_state_dict

    def act(self):
        return []

    def act_dict(self):
        joint_names = self._joint_states.name
        joint_positions = self._joint_states.position
        state_dict = {}

        for name in OUTPUT_JOINT_NAME:
            name_msg = ""

            if name == "head_pitch":
                name_msg = "head_pitch_joint"
            elif name == "head_yaw":
                name_msg = "head_yaw_joint"
            elif name == "head_roll":
                name_msg = "head_roll_joint"
            elif name == "left_joint1":
                name_msg = "shoulder_pitch_l_joint"
            elif name == "left_joint2":
                name_msg = "shoulder_roll_l_joint"
            elif name == "left_joint3":
                name_msg = "shoulder_yaw_l_joint"
            elif name == "left_joint4":
                name_msg = "elbow_pitch_l_joint"
            elif name == "left_joint5":
                name_msg = "elbow_yaw_l_joint"
            elif name == "left_joint6":
                name_msg = "wrist_pitch_l_joint"
            elif name == "left_joint7":
                name_msg = "wrist_roll_l_joint"
            elif name == "right_joint1":
                name_msg = "shoulder_pitch_r_joint"
            elif name == "right_joint2":
                name_msg = "shoulder_roll_r_joint"
            elif name == "right_joint3":
                name_msg = "shoulder_yaw_r_joint"
            elif name == "right_joint4":
                name_msg = "elbow_pitch_r_joint"
            elif name == "right_joint5":
                name_msg = "elbow_yaw_r_joint"
            elif name == "right_joint6":
                name_msg = "wrist_pitch_r_joint"
            elif name == "right_joint7":
                name_msg = "wrist_roll_r_joint"
            elif name == "waist_pitch":
                name_msg = "body_pitch_joint"
            elif name == "waist_yaw":
                name_msg = "body_yaw_joint"
            elif name == "waist_roll":
                name_msg = "body_roll_joint"
            elif name == "L_thumb_proximal_yaw_joint":
                name_msg = "L_thumb_proximal_yaw_joint"
            elif name == "L_thumb_intermediate_joint":
                name_msg = "L_thumb_intermediate_joint"
            elif name == "L_index_intermediate_joint":
                name_msg = "L_index_intermediate_joint"
            elif name == "L_middle_intermediate_joint":
                name_msg = "L_middle_intermediate_joint"
            elif name == "L_ring_intermediate_joint":
                name_msg = "L_ring_intermediate_joint"
            elif name == "L_pinky_intermediate_joint":
                name_msg = "L_pinky_intermediate_joint"
            elif name == "R_thumb_proximal_yaw_joint":
                name_msg = "R_thumb_proximal_yaw_joint"
            elif name == "R_thumb_intermediate_joint":
                name_msg = "R_thumb_intermediate_joint"
            elif name == "R_index_intermediate_joint":
                name_msg = "R_index_intermediate_joint"
            elif name == "R_middle_intermediate_joint":
                name_msg = "R_middle_intermediate_joint"
            elif name == "R_ring_intermediate_joint":
                name_msg = "R_ring_intermediate_joint"
            elif name == "R_pinky_intermediate_joint":
                name_msg = "R_pinky_intermediate_joint"
            elif name == "Height":
                name_msg = "Height"

            if name_msg in joint_names:
                data_idx = joint_names.index(
                    name_msg
                )  # find data index of a certian joint
                state_dict[name] = joint_positions[data_idx]
            else:
                state_dict[name] = 1

        self.bones_state_dict["timestamp"] = datetime.datetime.now()
        if (self.bones_state_dict["timestamp"] - self.dt).total_seconds() > 0.3:
            self.bones_state_dict['joints_state'] = state_dict
            path = Path(f"/home/eai/data/noitom").expanduser() / self.bones_state_dict["timestamp"].strftime("%m%d_%H%M%S")
            self.save_frame(path, self.bones_state_dict["timestamp"], self.bones_state_dict)
            self.dt = datetime.datetime.now()
        return state_dict

#include "mocap_utils.h"

#include <iostream>

MocapUtils::MocapUtils(const std::string& config_json) {
    // globalApp
    error = MCPGetGenericInterface(IMCPApplication_Version, reinterpret_cast<void**>(&pGlobalApp));
    error = pGlobalApp->CreateApplication(&globalAppHandle);
    // Settings
    MocapApi::MCPGetGenericInterface(IMCPSettings_Version, reinterpret_cast<void**>(&pGlobalSetting));
    pGlobalSetting->CreateSettings(&globalSettingHandle);
    int result = setMCPSettings(pGlobalSetting, globalSettingHandle);
    error = pGlobalApp->SetApplicationSettings(globalSettingHandle, globalAppHandle);
    error = pGlobalSetting->DestroySettings(globalSettingHandle);

    // avatar, sensormodule
    error = MCPGetGenericInterface(IMCPAvatar_Version, reinterpret_cast<void**>(&pAvatarInterface));
    error = MCPGetGenericInterface(IMCPSensorModule_Version, reinterpret_cast<void**>(&pImuInterface));
    // #ifdef _SUPORT_ALICE_NEW_
    error = MCPGetGenericInterface(IMCPMarker_Version, reinterpret_cast<void**>(&pMarkerInterface));
    // #endif
    error = MCPGetGenericInterface(IMCPRigidBody_Version,
                                   reinterpret_cast<void**>(&pRigidbodyInterface));  // PS: Rigidbody v2
    // #ifdef _SUPORT_ALICE_NEW_
    error = MCPGetGenericInterface(IMCPPWR_Version, reinterpret_cast<void**>(&pPWRInterface));
    error = MCPGetGenericInterface(IMCPAliceHub_Version, reinterpret_cast<void**>(&pAliceDataHub));
    // #endif
    error = MCPGetGenericInterface(IMCPTracker_Version, reinterpret_cast<void**>(&pDeviceInterface));

    MCPGetGenericInterface(IMCPJoint_Version, reinterpret_cast<void**>(&jointMgr));

    for (uint32_t i = 0; i < nMaxEventCount; i++) {
        pEvents[i].size = sizeof(MCPEvent_t);
    }

    // RenderSetting
    error = MCPGetGenericInterface(IMCPRenderSettings_Version, reinterpret_cast<void**>(&pRenderSetting));
    pRenderSetting->GetPreDefRenderSettings(PreDefinedRenderSettings_Default, &renderSettingHandle);
    pGlobalApp->SetApplicationRenderSettings(renderSettingHandle, globalAppHandle);

    // Go
    error = pGlobalApp->OpenApplication(globalAppHandle);

    //
    mRobotRetargeting = RetargetingCreateHandle(config_json.c_str());

    // ROS initialization
#if defined(ROS1)
    mPublisher = nh.advertise<sensor_msgs::JointState>("/joint_states", 10);
    mTfBroadcaster = std::make_unique<tf2_ros::TransformBroadcaster>();
#elif defined(ROS2)
    nh = std::make_shared<rclcpp::Node>("mocap_utils_node");
    mPublisher = nh->create_publisher<sensor_msgs::msg::JointState>("/joint_states", 10);
    mTfBroadcaster = std::make_unique<tf2_ros::TransformBroadcaster>(nh);
#endif

    mThread = new std::thread(&MocapUtils::MocapProcessLoop, this);
}

MocapUtils::~MocapUtils() {
    mThread->join();
    delete mThread;

    RetargetingDestroyHandle(mRobotRetargeting);

    error = pGlobalApp->CloseApplication(globalAppHandle);
    error = pGlobalApp->DestroyApplication(globalAppHandle);

    std::cout << "Destory MocapUtils" << std::endl;
}

int MocapUtils::setMCPSettings(IMCPSettings* setting, MCPSettingsHandle_t handle) {
    if (setting == nullptr || handle == 0) {
        return 1;
    }

    error = setting->SetSettingsBvhData(BvhDataType_Binary, handle);
    error = setting->SetSettingsBvhRotation(BvhRotation_XYZ, handle);
    error = setting->SetSettingsBvhTransformation(BvhTransformation_Disable, handle);
    // error = setting->SetSettingsTCP(strServerIP.c_str(), strServerPort, handle);
    // error = setting->SetSettingsUDPServer(strServerIP.c_str(), strServerPort, handle);
    error = setting->SetSettingsUDP(localPort, handle);
    return 0;
}

void MocapUtils::CreateMocapBones(MCPAvatarHandle_t mocapAvatarHandle, std::vector<MocapBone>& mocapBones) {
    uint32_t jointSize = 0;

    error = pAvatarInterface->GetAvatarJoints(nullptr, &jointSize, avatarHandle);
    error = pAvatarInterface->GetAvatarJoints(alljoint, &jointSize, avatarHandle);

    mocapBones.resize(jointSize);

    // std::cout << "Get " << jointSize << " MocapBones" << std::endl;
    for (size_t i = 0; i < jointSize; i++) {
        MocapBone& bone = mocapBones[i];

        MCPJointHandle_t joint = alljoint[i];

        const char* jointName = nullptr;
        error = jointMgr->GetJointName(&jointName, joint);

        EMCPJointTag jointTag;
        error = jointMgr->GetJointTag(&jointTag, joint);

        float jointPosition[3];
        error = jointMgr->GetJointLocalPosition(&jointPosition[0], &jointPosition[1], &jointPosition[2], joint);

        float jointRotation[4];  // w,x,y,z
        error = jointMgr->GetJointLocalRotation(&jointRotation[1], &jointRotation[2], &jointRotation[3],
                                                &jointRotation[0], joint);

        bone.mName = jointName;
        bone.mTag = jointTag;
        bone.mLocalPosition[0] = jointPosition[0];
        bone.mLocalPosition[1] = jointPosition[1];
        bone.mLocalPosition[2] = jointPosition[2];
        bone.mLocalRotation[0] = jointRotation[0];  // w
        bone.mLocalRotation[1] = jointRotation[1];
        bone.mLocalRotation[2] = jointRotation[2];
        bone.mLocalRotation[3] = jointRotation[3];

        MCPJointHandle_t childjoints[5];
        uint32_t numberOfChildren = 0;
        error = jointMgr->GetJointChild(nullptr, &numberOfChildren, joint);
        error = jointMgr->GetJointChild(childjoints, &numberOfChildren, joint);
        for (size_t j = 0; j < numberOfChildren; j++) {
            MCPJointHandle_t mcChildJoint = childjoints[j];
            const char* childName = nullptr;
            error = jointMgr->GetJointName(&childName, mcChildJoint);
            bone.msChildrenBoneName.push_back(childName);
        }
    }
}

void MocapUtils::MocapProcessLoop() {
    while (is_running()) {
        uint32_t nEventCount = 0;
        static size_t count = 0;
        error = pGlobalApp->PollApplicationNextEvent(nullptr, &nEventCount, globalAppHandle);
        if (nEventCount) {
            error = pGlobalApp->PollApplicationNextEvent(pEvents, &nEventCount, globalAppHandle);
            for (size_t i = 0; i < nEventCount; i++) {
                if (pEvents[i].eventType == MCPEvent_AvatarUpdated) {
                    avatarHandle = pEvents[i].eventData.motionData.avatarHandle;

                    std::vector<MocapBone> mocapBones;

                    CreateMocapBones(avatarHandle, mocapBones);
                    RetargetingUpdateMocapData(mRobotRetargeting, mocapBones);
                }
            }
        } else {
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
    }
}

#if defined(ROS1)
void MocapUtils::TimerDriveRobot(const ros::TimerEvent&) {
#elif defined(ROS2)
void MocapUtils::TimerDriveRobot() {
#endif
    if (!mRobotRetargeting) {
        return;
    }
    RetargetingResult result;
    bool res = RetargetingGetResult(mRobotRetargeting, result);

    if (res) {
#if defined(ROS1)
        sensor_msgs::JointState joint_state_msg;
        joint_state_msg.header.stamp = ros::Time::now();
        joint_state_msg.name = result.mName;
        joint_state_msg.position = result.mPosition;
        mPublisher.publish(joint_state_msg);

        geometry_msgs::TransformStamped transform;
        transform.header.stamp = joint_state_msg.header.stamp;
#elif defined(ROS2)
        sensor_msgs::msg::JointState joint_state_msg;
        joint_state_msg.header.stamp = nh->now();
        joint_state_msg.name = result.mName;
        joint_state_msg.position = result.mPosition;
        mPublisher->publish(joint_state_msg);

        geometry_msgs::msg::TransformStamped transform;
        transform.header.stamp = joint_state_msg.header.stamp;
#endif

        transform.header.frame_id = "odom";
        transform.child_frame_id = "pelvis";  // "base_link", "pelvis"

        // 设置平移
        transform.transform.translation.x = result.mRootPosition[0];
        transform.transform.translation.y = result.mRootPosition[1];
        transform.transform.translation.z = result.mRootPosition[2];

        // 设置旋转（四元数）
        transform.transform.rotation.w = result.mRootRotation[0];
        transform.transform.rotation.x = result.mRootRotation[1];
        transform.transform.rotation.y = result.mRootRotation[2];
        transform.transform.rotation.z = result.mRootRotation[3];

        // 广播 TF
        mTfBroadcaster->sendTransform(transform);
    }
}

#!/usr/bin/env python
import rospy
import os
import numpy as np
from sensor_msgs.msg import JointState


def callback(_joint_states):
    joint_names = _joint_states.name
    joint_positions = _joint_states.position
    # print(f"wrist_roll_l_joint {joint_positions[joint_names.index('wrist_roll_l_joint')]}")
    # print(f"wrist_pitch_r_joint {joint_positions[joint_names.index('wrist_pitch_r_joint')]}")

    left_hand_joints = np.zeros(6)
    left_hand_joints[0] = joint_positions[
        joint_names.index("L_thumb_proximal_yaw_joint")
    ]
    left_hand_joints[1] = joint_positions[
        joint_names.index("L_thumb_intermediate_joint")
    ]
    left_hand_joints[2] = joint_positions[
        joint_names.index("L_index_intermediate_joint")
    ]
    left_hand_joints[3] = joint_positions[
        joint_names.index("L_middle_intermediate_joint")
    ]
    left_hand_joints[4] = joint_positions[
        joint_names.index("L_ring_intermediate_joint")
    ]
    left_hand_joints[5] = joint_positions[
        joint_names.index("L_pinky_intermediate_joint")
    ]


def listener():
    rospy.init_node("js_sub", anonymous=True)

    rospy.Subscriber("/joint_states", JointState, callback)

    rospy.spin()


if __name__ == "__main__":
    REMOTE_IP = "10.10.247.167"
    os.environ["ROS_MASTER_URI"] = f"http://{REMOTE_IP}:11311"
    os.environ["ROS_IP"] = "10.10.247.168"
    listener()

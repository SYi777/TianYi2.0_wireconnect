import os
import rclpy
from sensor_msgs.msg import JointState
from geometry_msgs.msg import PoseArray
import uuid
from rclpy.qos import QoSProfile, ReliabilityPolicy, HistoryPolicy
from xtele.equipment.tele_base import TeleBase
import json
import pickle
from pathlib import Path
import datetime, time
from bodyctrl_msgs.msg import CmdSetMotorPosition, MotorStatusMsg, SetMotorPosition, CmdMotorCtrl, CmdSetMotorSpeed, MotorCtrl, SetMotorSpeed
import threading
from xrocs.utils.logger.logger_loader import logger
from xrocs.utils.ros2_node_manager import ros2_node_manager

OUTPUT_JOINT_NAME = [
    "head_pitch",
    "head_yaw",
    "head_roll",
    "left_joint1",
    "left_joint2",
    "left_joint3",
    "left_joint4",
    "left_joint5",
    "left_joint6",
    "left_joint7",
    "right_joint1",
    "right_joint2",
    "right_joint3",
    "right_joint4",
    "right_joint5",
    "right_joint6",
    "right_joint7",
    "waist_pitch",
    "waist_yaw",
    "waist_roll",
    "L_thumb_proximal_yaw_joint",
    "L_thumb_intermediate_joint",
    "L_index_intermediate_joint",
    "L_middle_intermediate_joint",
    "L_ring_intermediate_joint",
    "L_pinky_intermediate_joint",
    "R_thumb_proximal_yaw_joint",
    "R_thumb_intermediate_joint",
    "R_index_intermediate_joint",
    "R_middle_intermediate_joint",
    "R_ring_intermediate_joint",
    "R_pinky_intermediate_joint",
    "Height",
]

class Noitom():
    def __init__(self):
        self._joint_states = None
        qos_best_effort = QoSProfile(
            reliability=ReliabilityPolicy.BEST_EFFORT,
            history=HistoryPolicy.KEEP_LAST,
            depth=10,
        )
        
        self._joint_topic_name = "/joint_states"
        ros2_node_manager.acquire()
        self._joint_states_sub = ros2_node_manager._node.create_subscription(
                JointState, self._joint_topic_name, self._joint_states_callback, qos_best_effort)
        
        time.sleep(1)
    
    def _joint_states_callback(self, msg):
        self._joint_states = msg

    def act_dict(self):
        joint_names = self._joint_states.name
        joint_positions = self._joint_states.position
        state_dict = {}

        for name in OUTPUT_JOINT_NAME:
            name_msg = ""

            if name == "head_pitch":
                name_msg = "head_pitch_joint"
            elif name == "head_yaw":
                name_msg = "head_yaw_joint"
            elif name == "head_roll":
                name_msg = "head_roll_joint"
            elif name == "left_joint1":
                name_msg = "shoulder_pitch_l_joint"
            elif name == "left_joint2":
                name_msg = "shoulder_roll_l_joint"
            elif name == "left_joint3":
                name_msg = "shoulder_yaw_l_joint"
            elif name == "left_joint4":
                name_msg = "elbow_pitch_l_joint"
            elif name == "left_joint5":
                name_msg = "elbow_yaw_l_joint"
            elif name == "left_joint6":
                name_msg = "wrist_pitch_l_joint"
            elif name == "left_joint7":
                name_msg = "wrist_roll_l_joint"
            elif name == "right_joint1":
                name_msg = "shoulder_pitch_r_joint"
            elif name == "right_joint2":
                name_msg = "shoulder_roll_r_joint"
            elif name == "right_joint3":
                name_msg = "shoulder_yaw_r_joint"
            elif name == "right_joint4":
                name_msg = "elbow_pitch_r_joint"
            elif name == "right_joint5":
                name_msg = "elbow_yaw_r_joint"
            elif name == "right_joint6":
                name_msg = "wrist_pitch_r_joint"
            elif name == "right_joint7":
                name_msg = "wrist_roll_r_joint"
            elif name == "waist_pitch":
                name_msg = "body_pitch_joint"
            elif name == "waist_yaw":
                name_msg = "body_yaw_joint"
            elif name == "waist_roll":
                name_msg = "body_roll_joint"
            elif name == "L_thumb_proximal_yaw_joint":
                name_msg = "L_thumb_proximal_yaw_joint"
            elif name == "L_thumb_intermediate_joint":
                name_msg = "L_thumb_intermediate_joint"
            elif name == "L_index_intermediate_joint":
                name_msg = "L_index_intermediate_joint"
            elif name == "L_middle_intermediate_joint":
                name_msg = "L_middle_intermediate_joint"
            elif name == "L_ring_intermediate_joint":
                name_msg = "L_ring_intermediate_joint"
            elif name == "L_pinky_intermediate_joint":
                name_msg = "L_pinky_intermediate_joint"
            elif name == "R_thumb_proximal_yaw_joint":
                name_msg = "R_thumb_proximal_yaw_joint"
            elif name == "R_thumb_intermediate_joint":
                name_msg = "R_thumb_intermediate_joint"
            elif name == "R_index_intermediate_joint":
                name_msg = "R_index_intermediate_joint"
            elif name == "R_middle_intermediate_joint":
                name_msg = "R_middle_intermediate_joint"
            elif name == "R_ring_intermediate_joint":
                name_msg = "R_ring_intermediate_joint"
            elif name == "R_pinky_intermediate_joint":
                name_msg = "R_pinky_intermediate_joint"
            elif name == "Height":
                name_msg = "Height"

            if name_msg in joint_names:
                data_idx = joint_names.index(
                    name_msg
                )  # find data index of a certian joint
                state_dict[name] = joint_positions[data_idx]
            else:
                state_dict[name] = 1.0

        return state_dict

if __name__ == "__main__":

    noitom = Noitom()
    print(noitom.act_dict())
    rclpy.shutdown()
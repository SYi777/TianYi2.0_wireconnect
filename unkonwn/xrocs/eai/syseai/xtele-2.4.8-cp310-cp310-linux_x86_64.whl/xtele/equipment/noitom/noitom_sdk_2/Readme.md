
run

    catkin_make

to generate the compiled files.

run

    rosrun nr-retargeting-benchmark-cpp benchmark-cpp tiangong2

to start noitom transfer node.
the motion capture topic name is '/joint_states'.
